exports.buyerDashboard = (req, res) => {
  res.json({ message: 'Buyer dashboard data' });
}; 