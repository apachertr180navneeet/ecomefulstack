exports.adminDashboard = (req, res) => {
  res.json({ message: 'Admin dashboard data' });
}; 